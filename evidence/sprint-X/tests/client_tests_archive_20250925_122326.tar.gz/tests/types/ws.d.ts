declare module 'ws' {
  export = WebSocket;
  export as namespace WebSocket;
}
